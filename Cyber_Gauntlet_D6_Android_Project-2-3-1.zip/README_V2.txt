# Cyber Gauntlet D-6 / Android v2.0

This is the Android project root. It is ready for the existing GitHub Actions
workflow that extracts `Cyber_Gauntlet_D6_Android_Project-2.zip` and runs
`gradle :app:assembleDebug`.

## Changes
- Refreshed dark Mission Control interface, larger text, a more compact question screen.
- Updated four-option layout that fits 390 x 844 and 360 x 800 test viewports.
- Corrected KPI tab layout and route navigation.
- Supplied full MP3 track (3 min 55 sec), not the nearly inaudible 20-second loop.
- Native Android MediaPlayer controls sound for reliable playback and background pausing.
- Sound panel with play/pause, current status, and saved volume level (default 32%).
- New package ID `no.cybergauntlet.d6.v2`: installs alongside original APK, which
  avoids debug signing key conflicts and leaves old game results unchanged.
- Norwegian and English, 22+ branching injects, Excel import, reports and export preserved.

## Important: audio and public GitHub
This project includes a user-supplied MP3. Uploading this ZIP to a PUBLIC repository
makes the audio downloadable by anyone. Only publish if you have permission to
redistribute the recording and any underlying musical work.

## Testing status
The HTML UI, JS syntax, branching navigation, KPI panels, and AndroidBridge
control calls were tested in a mobile Chromium harness (360/390/430px widths).
The native Java source has not yet been compiled or run on a physical Android device.
A successful GitHub Actions run and installation are still required.
