# Cyber Gauntlet D−6 – mobilapp (PWA)

## Innhold
- `index.html`: språkvelger og installasjon
- `no.html` og `en.html`: fullverdige mobiltilpassede spill
- `assets/music.mp3`: brukerens musikkspor, innbakt i app-pakken for offline bruk
- `Scenario_Bibliotek.xlsx`: redigerbart scenario med injects, svar og KPI-effekter
- `manifest.webmanifest`, `sw.js` og appikoner: installasjon og offline-lagring

## Bruk

### Mobilapp på Android (uten APK)
1. Pakk ut ZIP-filen, og publiser **hele innholdet** på en HTTPS-nettside, f.eks. bedriftens webserver eller en statisk webhost.
2. Åpne `https://<din-adresse>/` i Chrome på Android.
3. Trykk **Installer Cyber Gauntlet**, eller Chrome-menyen → **Installer app** / **Legg til på startskjermen**.
4. Åpne appen fra ikonet på hjemskjermen. Første installasjon mellomlagrer spill og lyd for offline bruk.

### iPhone
1. Åpne den publiserte HTTPS-adressen i Safari.
2. Trykk Del → **Legg til på Hjem-skjerm** (i noen versjoner: Mer → Legg til på Hjem-skjerm).
3. Start via appikonet. Spillfunksjonene er offline etter vellykket mellomlagring.

### Test på PC (uten å publisere)
Kjør fra mappen:
`python -m http.server 8000`
Åpne `http://localhost:8000/` i Chrome. Lokale HTTPS-unntak gjelder for `localhost`.
Det går også an å åpne `no.html`/`en.html` direkte fra filsystemet for forhåndsvisning, men installasjon og offline-service-worker krever HTTPS/localhost.

## Endre scenario
Rediger den vedlagte `Scenario_Bibliotek.xlsx`. I spillet velger du **Importer Excel** på startsiden. Filen leses bare i nettleseren; den lastes ikke opp til en server. Innholdet i den aktuelle spilløkten byttes ut.

## Spesifikasjoner og begrensninger
- Dette er en **installerbar webapp (PWA)**, ikke en ferdig signert Android `.apk` eller iOS `.ipa`.
- Sammenlignet med en native app krever installasjonen at filene først publiseres på en sikker HTTPS-adresse.
- Musikken starter ved brukerens trykk på **Start øvelsen**; mobilen kan blokkere automatisk avspilling hvis lyd er deaktivert.
- PDF-utskrift, CSV-eksport og import av Excel bruker mobilnettleserens funksjoner, så detaljene varierer etter operativsystem.
- Spillet lagrer resultatlisten lokalt på enheten. Det finnes ingen sentral resultatdatabase, synkronisering eller innlogging.
- Husk rettigheter/lisens til MP3-lydsporet dersom appen skal deles eller publiseres offentlig.
- PWA-visning kan ikke installeres fra en lokal `file://`-lenke.
