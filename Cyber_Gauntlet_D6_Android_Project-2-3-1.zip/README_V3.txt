CYBER GAUNTLET D-6 — V3.0 (Vivicta brand)
=======================================
Android Studio project; automatic GitHub Actions build uses Gradle.
Unique application ID no.cybergauntlet.d6.v3: installs alongside older versions without a signing collision.

WHAT'S NEW
- Updated brand palette: Vivicta forest green, fresh mint and white.
- Employer selection is required at each player sign-in. Players choose the Vivicta or Gjensidige logo.
- The employer is saved with the player's results and included in leaderboard and CSV.
- New offline music: Du er ute (1.19x).mp3, supplied by the user.
- More compact mobile mission layout and improved readability.
- Both Norwegian and English game pages included; all inject decisions and Excel editing preserved.

HOW TO BUILD
1. In GitHub, replace Cyber_Gauntlet_D6_Android_Project-2-3.zip with the ZIP supplied alongside this README.
2. The existing workflow should unzip that exact filename to android-project.
3. Commit the changed ZIP. GitHub Actions > Build Cyber Gauntlet APK will run automatically.
4. Download the latest successful run's APK artifact and install on Android.

VERIFY
Check ZIP size about 4.7 MB, and APK larger than prior 1.75 MB build due to music.
In the new app: choose language, enter a player name, select one company logo, press Start.

NOTE
This project includes an MP3. Uploading it to a PUBLIC GitHub repository makes it publicly accessible. Only upload if you are authorized to distribute the recording.

This is a debug/test Android APK build, not a Play Store release.
