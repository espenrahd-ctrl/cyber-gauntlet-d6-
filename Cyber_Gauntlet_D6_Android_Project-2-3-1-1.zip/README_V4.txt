Cyber Gauntlet D-6 · Responsibility Edition 4.0

All 31 injects show a clear mission lead with the appropriate real company logo. For shared injects, a single exercise lead is chosen as a scenario-specific training convention, not a contractual RACI statement. The player-selected employer remains independent.

New: modern light green UI, accessible high-contrast best answer explanations, logo badge on each mission scene and route map, lead tags in result report.

Music: Du er ute (1.19x).mp3. Rights to publish the audio in public GitHub must be confirmed by the owner.

Upload ZIP preserving the exact filename expected by .github/workflows/build-android.yml.
