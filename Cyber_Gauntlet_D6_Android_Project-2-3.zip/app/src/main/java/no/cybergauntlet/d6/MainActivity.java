package no.cybergauntlet.d6;

import android.app.Activity;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.Locale;

/**
 * Offline single-activity wrapper. Serves bundled local HTML as a trusted
 * HTTPS-like origin, without requiring an external website or a server.
 * No data is uploaded to a backend. Scores remain on this device.
 */
public class MainActivity extends Activity {
    private static final int REQ_EXCEL = 301;
    private static final int REQ_SAVE = 302;
    private static final String BASE_URL = "https://appassets.androidplatform.net/assets/";
    private WebView webView;
    private WebChromeClient.FileChooserParams chooserParams;
    private android.webkit.ValueCallback<Uri[]> chooserCallback;
    private byte[] pendingSaveBytes;
    private MediaPlayer musicPlayer;
    private boolean resumeMusic = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7, 20, 34));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7, 20, 34));
        webView = new WebView(this);
        webView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(webView);

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .setDomain("appassets.androidplatform.net")
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(false);
        WebView.setWebContentsDebuggingEnabled(false);

        // JavaScript interface is safe here because all external links open
        // in another browser rather than entering this WebView.
        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())
                    && "https".equalsIgnoreCase(uri.getScheme())
                    && uri.getPath() != null && uri.getPath().startsWith("/assets/")) {
                    return false;
                }
                // Best-practice references and other external links open in
                // the device browser, never in the privileged local WebView.
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    intent.addCategory(Intent.CATEGORY_BROWSABLE);
                    startActivity(intent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this, "No browser available", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                // Installed Android application: hide the PWA-only install button.
                if (url.endsWith("/index.html") || url.endsWith("/")) {
                    view.evaluateJavascript("(function(){var b=document.getElementById('installButton');if(b)b.style.display='none';var h=document.getElementById('installHint');if(h)h.textContent='Appen er installert. Velg språk for å starte.';})()", null);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view,
                    android.webkit.ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                chooserParams = params;
                try {
                    Intent fileIntent = params.createIntent();
                    startActivityForResult(fileIntent, REQ_EXCEL);
                    return true;
                } catch (Exception ex) {
                    chooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "Could not open file picker", Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });
        webView.loadUrl(BASE_URL + "index.html");
    }


    private void broadcastMusicState(boolean playing, boolean failed) {
        if (webView != null) {
            webView.evaluateJavascript("window.cgNativeMusicUpdate && window.cgNativeMusicUpdate(" +
                (playing ? "true" : "false") + "," + (failed ? "true" : "false") + ");", null);
        }
    }

    private void playMusicOnMainThread(float volume) {
        try {
            if (musicPlayer == null) {
                musicPlayer = new MediaPlayer();
                try (AssetFileDescriptor afd = getAssets().openFd("assets/music.mp3")) {
                    musicPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                }
                musicPlayer.setLooping(true);
                musicPlayer.prepare();
            }
            final float v = Math.max(0f, Math.min(1f, volume));
            musicPlayer.setVolume(v, v);
            musicPlayer.start();
            broadcastMusicState(true, false);
        } catch (Exception ex) {
            android.util.Log.e("CyberGauntlet", "Music playback failed", ex);
            if (musicPlayer != null) {
                try { musicPlayer.release(); } catch (Exception ignored) { }
                musicPlayer = null;
            }
            broadcastMusicState(false, true);
        }
    }

    private final class AppBridge {
        @JavascriptInterface
        public void playMusic(float volume) {
            runOnUiThread(() -> playMusicOnMainThread(volume));
        }
        @JavascriptInterface
        public void pauseMusic() {
            runOnUiThread(() -> {
                resumeMusic = false;
                if (musicPlayer != null && musicPlayer.isPlaying()) musicPlayer.pause();
                broadcastMusicState(false, false);
            });
        }
        @JavascriptInterface
        public void setMusicVolume(float volume) {
            runOnUiThread(() -> {
                if (musicPlayer != null) {
                    float v = Math.max(0f, Math.min(1f, volume));
                    musicPlayer.setVolume(v, v);
                }
            });
        }
        @JavascriptInterface
        public void saveFile(String base64, String filename, String mimeType) {
            // Limit JS-facing transfer size and reject malformed base64.
            if (base64 == null || base64.length() > 16_000_000) return;
            byte[] bytes;
            try { bytes = Base64.decode(base64, Base64.DEFAULT); }
            catch (IllegalArgumentException ex) { return; }
            final byte[] payload = bytes;
            final String safeName = filename == null ? "CyberGauntlet.csv"
                : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
            final String safeMime = (mimeType == null || mimeType.isEmpty())
                ? "application/octet-stream" : mimeType;
            runOnUiThread(() -> {
                pendingSaveBytes = payload;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType(safeMime);
                create.putExtra(Intent.EXTRA_TITLE, safeName);
                try { startActivityForResult(create, REQ_SAVE); }
                catch (ActivityNotFoundException ex) {
                    Toast.makeText(MainActivity.this, "No file manager available", Toast.LENGTH_LONG).show();
                    pendingSaveBytes = null;
                }
            });
        }
        @JavascriptInterface
        public void printScreen() {
            runOnUiThread(() -> {
                PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                if (manager != null && webView != null) {
                    manager.print("Cyber Gauntlet D-6",
                        webView.createPrintDocumentAdapter("Cyber Gauntlet D-6"),
                        new PrintAttributes.Builder().build());
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXCEL) {
            if (chooserCallback != null) {
                chooserCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                chooserCallback = null;
                chooserParams = null;
            }
        } else if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null
                && pendingSaveBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("No output stream");
                    output.write(pendingSaveBytes);
                    output.flush();
                    Toast.makeText(this, "File saved", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(this, "Could not save file", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        // Pause native music when another application is in front.
        if (musicPlayer != null) {
            resumeMusic = musicPlayer.isPlaying();
            if (resumeMusic) musicPlayer.pause();
        }
        if (webView != null) {
            webView.evaluateJavascript("(function(){var a=document.getElementById('bgMusic');if(a)a.pause()})()", null);
            webView.onPause();
        }
        super.onPause();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
        if (resumeMusic && musicPlayer != null) {
            musicPlayer.start();
            broadcastMusicState(true, false);
        }
        resumeMusic = false;
    }
    @Override
    protected void onDestroy() {
        if (musicPlayer != null) {
            musicPlayer.release();
            musicPlayer = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
